# imooc_logprocess

Source code for imooc [https://www.imooc.com/learn/982](https://www.imooc.com/learn/982)
